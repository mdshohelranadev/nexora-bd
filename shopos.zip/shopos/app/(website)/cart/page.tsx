// app/(website)/cart/page.tsx

'use client';

import Link from 'next/link';
import Image from 'next/image';
import {
  Minus,
  Plus,
  Trash2,
  ShoppingBag,
  ArrowRight,
  ArrowLeft,
  Truck,
  ShieldCheck,
  Tag,
} from 'lucide-react';
import { toast } from 'sonner';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { EmptyState } from '@/components/shared/empty-state';
import { useWebCart } from '@/lib/store/web-cart-store';
import { formatCurrency } from '@/lib/format';

const FREE_DELIVERY_THRESHOLD = 5000;
const DELIVERY_CHARGE = 80;

export default function CartPage() {
  const cart = useWebCart();
  const subtotal = cart.subtotal();
  const count = cart.count();

  const delivery =
    subtotal === 0 || subtotal >= FREE_DELIVERY_THRESHOLD ? 0 : DELIVERY_CHARGE;
  const total = subtotal + delivery;
  const remaining = Math.max(0, FREE_DELIVERY_THRESHOLD - subtotal);

  if (cart.items.length === 0) {
    return (
      <div className="container mx-auto py-10 md:py-16">
        <Card>
          <CardContent className="p-6 md:p-10">
            <EmptyState
              icon={ShoppingBag}
              title="Your cart is empty"
              description="Browse our catalog and add tools to your cart."
              action={
                <Button asChild>
                  <Link href="/shop">
                    <ArrowLeft className="h-4 w-4 mr-2" />
                    Continue Shopping
                  </Link>
                </Button>
              }
            />
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-6 md:py-8">
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-2xl md:text-3xl font-bold tracking-tight">
          Shopping Cart
        </h1>
        <p className="text-xs md:text-sm text-muted-foreground mt-1">
          {count} item{count === 1 ? '' : 's'} in your cart
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_360px] gap-6">
        {/* Left: items */}
        <div className="space-y-3">
          {cart.items.map((it) => (
            <Card key={it.productId} className="overflow-hidden">
              <CardContent className="p-3 md:p-4">
                <div className="flex gap-3 md:gap-4">
                  {/* Thumbnail */}
                  <Link
                    href={`/product/${it.productId}`}
                    className="h-20 w-20 md:h-24 md:w-24 rounded-lg bg-gradient-to-br from-indigo-500/10 to-violet-500/10 flex items-center justify-center shrink-0"
                  >
                    <span className="text-lg font-bold text-indigo-500/40">
                      {it.name.slice(0, 2).toUpperCase()}
                    </span>
                  </Link>

                  {/* Info */}
                  <div className="min-w-0 flex-1 flex flex-col">
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <Link
                          href={`/product/${it.productId}`}
                          className="text-sm md:text-base font-medium leading-snug line-clamp-2 hover:text-indigo-600 dark:hover:text-indigo-400"
                        >
                          {it.name}
                        </Link>
                        <div className="text-[10px] md:text-xs text-muted-foreground mt-0.5">
                          SKU: {it.sku}
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          cart.remove(it.productId);
                          toast.success('Removed from cart');
                        }}
                        className="p-1.5 -mr-1 -mt-1 rounded-md text-muted-foreground hover:text-red-500 hover:bg-red-500/10 shrink-0"
                        aria-label="Remove"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>

                    <div className="flex-1" />

                    <div className="flex items-center justify-between gap-3 mt-3 flex-wrap">
                      {/* Qty */}
                      <div className="inline-flex items-center border rounded-md h-9 bg-background">
                        <button
                          type="button"
                          onClick={() =>
                            cart.updateQty(it.productId, it.qty - 1)
                          }
                          className="w-9 h-full flex items-center justify-center hover:bg-muted rounded-l-md disabled:opacity-40"
                          aria-label="Decrease"
                        >
                          <Minus className="h-3.5 w-3.5" />
                        </button>
                        <div className="w-10 text-center text-sm font-semibold tabular-nums">
                          {it.qty}
                        </div>
                        <button
                          type="button"
                          onClick={() =>
                            cart.updateQty(it.productId, it.qty + 1)
                          }
                          disabled={it.qty >= it.stock}
                          className="w-9 h-full flex items-center justify-center hover:bg-muted rounded-r-md disabled:opacity-40"
                          aria-label="Increase"
                        >
                          <Plus className="h-3.5 w-3.5" />
                        </button>
                      </div>

                      {/* Price */}
                      <div className="text-right">
                        <div className="text-[10px] md:text-xs text-muted-foreground">
                          {formatCurrency(it.price)} × {it.qty}
                        </div>
                        <div className="text-base md:text-lg font-bold tabular-nums">
                          {formatCurrency(it.price * it.qty)}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}

          {/* Continue shopping */}
          <div className="flex items-center justify-between gap-3 pt-2 flex-wrap">
            <Button asChild variant="ghost" size="sm" className="h-9">
              <Link href="/shop">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Continue Shopping
              </Link>
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="h-9 text-red-600 hover:text-red-600 hover:bg-red-500/10"
              onClick={() => {
                cart.clear();
                toast.success('Cart cleared');
              }}
            >
              <Trash2 className="h-4 w-4 mr-2" />
              Clear Cart
            </Button>
          </div>
        </div>

        {/* Right: order summary */}
        <div className="lg:sticky lg:top-20 self-start">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Order Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {/* Free delivery progress */}
              {remaining > 0 ? (
                <div className="rounded-lg border bg-amber-500/5 border-amber-500/20 p-3">
                  <div className="flex items-center gap-2 text-xs text-amber-700 dark:text-amber-400">
                    <Truck className="h-3.5 w-3.5 shrink-0" />
                    <span>
                      Add{' '}
                      <span className="font-semibold">
                        {formatCurrency(remaining)}
                      </span>{' '}
                      more for free delivery
                    </span>
                  </div>
                  <div className="mt-2 h-1.5 rounded-full bg-amber-500/20 overflow-hidden">
                    <div
                      className="h-full bg-amber-500 transition-all duration-500"
                      style={{
                        width: `${Math.min(100, (subtotal / FREE_DELIVERY_THRESHOLD) * 100)}%`,
                      }}
                    />
                  </div>
                </div>
              ) : (
                <div className="rounded-lg border bg-emerald-500/5 border-emerald-500/20 p-3 flex items-center gap-2 text-xs text-emerald-700 dark:text-emerald-400">
                  <Truck className="h-3.5 w-3.5 shrink-0" />
                  <span className="font-medium">
                    You qualify for FREE delivery
                  </span>
                </div>
              )}

              <Separator />

              {/* Calculations */}
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Subtotal</span>
                  <span className="tabular-nums font-medium">
                    {formatCurrency(subtotal)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Delivery</span>
                  <span className="tabular-nums font-medium">
                    {delivery === 0 ? (
                      <span className="text-emerald-600 dark:text-emerald-400 font-semibold">
                        FREE
                      </span>
                    ) : (
                      formatCurrency(delivery)
                    )}
                  </span>
                </div>
              </div>

              <Separator />

              <div className="flex justify-between items-baseline">
                <span className="text-sm font-semibold">Total</span>
                <span className="text-xl font-bold tabular-nums text-indigo-600 dark:text-indigo-400">
                  {formatCurrency(total)}
                </span>
              </div>

              <p className="text-[10px] text-muted-foreground flex items-start gap-1.5">
                <Tag className="h-3 w-3 shrink-0 mt-0.5" />
                Inclusive of all taxes. Final amount confirmed at checkout.
              </p>

              <Button
                asChild
                size="lg"
                className="w-full h-11"
              >
                <Link href="/checkout">
                  Proceed to Checkout
                  <ArrowRight className="h-4 w-4 ml-2" />
                </Link>
              </Button>

              {/* Trust */}
              <div className="pt-2 space-y-2 text-xs text-muted-foreground">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="h-3.5 w-3.5 text-emerald-500 shrink-0" />
                  <span>Secure checkout · SSL encrypted</span>
                </div>
                <div className="flex items-center gap-2">
                  <Truck className="h-3.5 w-3.5 text-indigo-500 shrink-0" />
                  <span>Delivery within 2-5 working days</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}